module.exports = {
    uri: 'mongodb://localhost:27017/',
    user: '',
    password: '',
    db: 'clife-chat',
    collections: {
        usuarios: 'usuarios',
        mensajes: 'mensajes',
        contactos: 'contactos',
        grupos: 'grupos',
        notificaciones: 'notificaciones'
    }
}