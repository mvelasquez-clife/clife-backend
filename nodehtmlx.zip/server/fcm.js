module.exports = {
    api_key: 'AIzaSyCSXYKYSDIfQEVwyE-TEACs9E4DDJmoUns',
    base_url: 'https://fcm.googleapis.com/fcm/send'
};