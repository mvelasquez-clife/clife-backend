module.exports = {
    address: '*'
};