module.exports = {
    host: '192.168.0.250',
    user: 'admlife',
    password: 'L1f3$21'
};