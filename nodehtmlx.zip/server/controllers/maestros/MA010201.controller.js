const oracledb = require('oracledb');
const dbParams = require('../../database');
const o2x = require('object-to-xml');

const responseParams = {
    outFormat: oracledb.OBJECT
};

const ma010201Controller = {
    //
};

module.exports = ma010201Controller;