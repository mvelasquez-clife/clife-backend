module.exports = {
    host: '192.168.0.248',
    //secure: 'control',
    user: 'admlife',
    password: 'L1f3$21'
};