const jwtKey =
        {jwtkeylogin: '#Th3/Keyb0ard|C4t*', jwtforgotexpire: 3600, jwtloginexpire: 86400};


module.exports = jwtKey;