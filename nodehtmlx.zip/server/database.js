
module.exports = {
    user: 'desarrollo',
    password: 'Sp343DanielaA',
    connectString: '(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = 192.168.1.247)(PORT = 1521)))(CONNECT_DATA = (SID = orcl) (SERVER = DEDICATED)))'
    /*user: 'desarrollo',
    password: 'desarrollo2131',
    connectString: '(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = lifeoraprd.cwweyutifkcl.us-west-2.rds.amazonaws.com)(PORT = 1521)))(CONNECT_DATA = (SID = orcl) (SERVER = DEDICATED)))'*/
};