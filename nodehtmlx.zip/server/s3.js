module.exports = {
    credenciales: {
        accessKeyId: "AKIAIBVURTIM24KQL6NA",
        secretAccessKey: "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"
    },
    bucket: 'imagenes-clife'
}