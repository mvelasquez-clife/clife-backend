const express = require('express');
const router = express.Router();

const ma010201Controller = require('../../controllers/maestros/MA010201.controller');

module.exports = router;